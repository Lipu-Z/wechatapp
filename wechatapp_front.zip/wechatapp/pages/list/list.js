// pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
     var that = this;
     wx.request({
       url: 'http://localhost:7070/wechatapp/superadmin/listarea',
       method: 'GET',
       data:{},
       success:function(res){
         var list = res.data.areaList;
         if(list==null){
           var toastText = 'Retreat info failed' + res.data.errMsg;
           wx.showToast({
             title: 'toastText',
             icon:'',
             duration:2000
           })
         } else {
           that.setData({
             list:list
           })
         }
       }
     })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  addArea: function(){
    wx.navigateTo({
      url: '../operation/operation',
    })
  },

  deleteArea: function(e){
    var that = this;
    wx.showModal({
      title: 'Warning',
      content: 'Do you want to delete ' + e.target.dataset.areaname +'?',
      success: function(sm) {
        if(sm.confirm) {
          wx.request({
            url: 'http://localhost:7070/wechatapp/superadmin/removeArea',
            data:{'Id':e.target.dataset.areaid},
            method:'GET',
            success: function(res){
              var result = res.data.success;
              var toastText = "delete successfully";
              if(result != true) {
                toastText = "delete failed";
              } else {
                that.data.list.splice(e.target.dataset.index, 1);
                that.setData({
                  list: that.data.list
                })
              }
              wx.showToast({
                title: toastText,
                icon:'',
                duration:2000
              })
            }
          })
        }
      }
    })
  }
})